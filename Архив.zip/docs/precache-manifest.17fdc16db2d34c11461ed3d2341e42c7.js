self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "546bd0b8575a33fd7304f9981e236554",
    "url": "/deferral/index.html"
  },
  {
    "revision": "f63f31fd508becaecb67",
    "url": "/deferral/static/css/main.f57910f7.chunk.css"
  },
  {
    "revision": "a4fb6e0af16065c99bea",
    "url": "/deferral/static/js/2.df86a64f.chunk.js"
  },
  {
    "revision": "89b0379e7bcda1a468d8b0343aeb4e53",
    "url": "/deferral/static/js/2.df86a64f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f63f31fd508becaecb67",
    "url": "/deferral/static/js/main.9cc50c22.chunk.js"
  },
  {
    "revision": "d359c9707d08b96a241d",
    "url": "/deferral/static/js/runtime-main.329a55dd.js"
  }
]);