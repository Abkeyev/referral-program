import { withStyles } from '@material-ui/core/styles'
import RadioGroup from '@material-ui/core/RadioGroup'

const BccRadioGroup = withStyles({
  root: {},
})(RadioGroup)

export default BccRadioGroup
