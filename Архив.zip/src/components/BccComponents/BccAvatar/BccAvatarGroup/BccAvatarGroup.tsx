import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import AvatarGroup from '@material-ui/lab/AvatarGroup'

const BccAvatarGroup = withStyles({
  root: {},
})(AvatarGroup)

export default BccAvatarGroup
