import TableRow from '@material-ui/core/TableRow'
import React from 'react'
import { withStyles } from '@material-ui/core/styles'

const BccTableRow = withStyles({})((props: any) => <TableRow {...props} />)

export default BccTableRow
