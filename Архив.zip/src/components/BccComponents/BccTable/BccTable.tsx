import Table from '@material-ui/core/Table'
import React from 'react'
import { withStyles } from '@material-ui/core/styles'

const BccTable = withStyles({})((props: any) => <Table {...props} />)

export default BccTable
