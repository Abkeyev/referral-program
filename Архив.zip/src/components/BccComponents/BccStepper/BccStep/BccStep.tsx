import React from 'react'
import Step from '@material-ui/core/Step'
import { withStyles } from '@material-ui/core/styles'

const BccStep = withStyles({
  root: {},
})((props: any) => <Step {...props} />)

export default BccStep
