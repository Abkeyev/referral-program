import ButtonGroup from '@material-ui/core/ButtonGroup'
import { withStyles } from '@material-ui/core/styles'

const BccButtonGroup = withStyles({
  root: {},
})(ButtonGroup)

export default BccButtonGroup
