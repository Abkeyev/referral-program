import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import React from 'react'

const BccGrid = withStyles({})((props: any) => <Grid {...props} />)

export default BccGrid
