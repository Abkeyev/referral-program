export { default as Slider } from "./Slider";
export { default as Tabs } from "./Tabs";
export { default as Footer } from "./Footer";
export { default as Order } from "./Order";
