window.env = {
  OTP_URL: "https://wifi.bcc.kz",
  GREEN_API_OTP: "https://green.bcc.kz/camunda",
  GREEN_API: "https://green.bcc.kz/camunda",
  REFERENCE_API: "https://green.bcc.kz/reference",
  PRODUCTION: "1",
};
